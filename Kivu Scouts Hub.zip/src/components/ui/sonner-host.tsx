import { Toaster } from "sonner";

export function SonnerHost() {
  return <Toaster theme="dark" position="top-center" richColors closeButton />;
}