-- Albums (photo/video collections)
CREATE TYPE public.media_kind AS ENUM ('photo', 'video');

CREATE TABLE public.albums (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  cover_url text,
  kind public.media_kind NOT NULL DEFAULT 'photo',
  sort_order integer NOT NULL DEFAULT 0,
  status public.content_status NOT NULL DEFAULT 'draft',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.albums TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.albums TO authenticated;
GRANT ALL ON public.albums TO service_role;
ALTER TABLE public.albums ENABLE ROW LEVEL SECURITY;
CREATE POLICY "albums_public_read" ON public.albums FOR SELECT
  USING (status = 'published' OR public.is_admin(auth.uid()));
CREATE POLICY "albums_admin_write" ON public.albums FOR ALL
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE TRIGGER trg_albums_updated BEFORE UPDATE ON public.albums
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- Media items inside albums
CREATE TABLE public.media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  album_id uuid NOT NULL REFERENCES public.albums(id) ON DELETE CASCADE,
  kind public.media_kind NOT NULL DEFAULT 'photo',
  title text,
  caption text,
  url text NOT NULL,
  storage_path text,
  mime text,
  size bigint,
  sort_order integer NOT NULL DEFAULT 0,
  status public.content_status NOT NULL DEFAULT 'published',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.media TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.media TO authenticated;
GRANT ALL ON public.media TO service_role;
ALTER TABLE public.media ENABLE ROW LEVEL SECURITY;
CREATE POLICY "media_public_read" ON public.media FOR SELECT
  USING (status = 'published' OR public.is_admin(auth.uid()));
CREATE POLICY "media_admin_write" ON public.media FOR ALL
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE TRIGGER trg_media_updated BEFORE UPDATE ON public.media
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();
CREATE INDEX idx_media_album ON public.media(album_id, sort_order);

-- Notifications (admin-only)
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text,
  kind text NOT NULL DEFAULT 'info',
  link text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif_own_or_broadcast_read" ON public.notifications FOR SELECT
  USING (
    public.is_admin(auth.uid())
    AND (user_id IS NULL OR user_id = auth.uid())
  );
CREATE POLICY "notif_admin_insert" ON public.notifications FOR INSERT
  WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "notif_own_update" ON public.notifications FOR UPDATE
  USING (public.is_admin(auth.uid()) AND (user_id IS NULL OR user_id = auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "notif_admin_delete" ON public.notifications FOR DELETE
  USING (public.is_admin(auth.uid()));
CREATE INDEX idx_notifications_user_created ON public.notifications(user_id, created_at DESC);
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Activity logs (audit trail of admin actions)
CREATE TABLE public.activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_email text,
  action text NOT NULL,
  entity text,
  entity_id text,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.activity_logs TO authenticated;
GRANT ALL ON public.activity_logs TO service_role;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "logs_admin_read" ON public.activity_logs FOR SELECT
  USING (public.is_admin(auth.uid()));
CREATE POLICY "logs_authenticated_insert" ON public.activity_logs FOR INSERT
  WITH CHECK (auth.uid() = actor_id);
CREATE INDEX idx_logs_created ON public.activity_logs(created_at DESC);

-- Auto-notify admins + log when a new inscription arrives
CREATE OR REPLACE FUNCTION public.notify_new_inscription()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, kind, link)
  SELECT ur.user_id,
         'Nouvelle demande d''inscription',
         NEW.full_name || ' (' || NEW.type || ')',
         'inscription',
         '/admin/inscriptions'
  FROM public.user_roles ur
  WHERE ur.role IN ('super_admin', 'admin');

  INSERT INTO public.activity_logs (actor_id, actor_email, action, entity, entity_id, meta)
  VALUES (NULL, NEW.email, 'inscription.created', 'inscription', NEW.id::text,
          jsonb_build_object('type', NEW.type, 'full_name', NEW.full_name));
  RETURN NEW;
END $$;

CREATE TRIGGER trg_notify_new_inscription
  AFTER INSERT ON public.inscriptions
  FOR EACH ROW EXECUTE FUNCTION public.notify_new_inscription();