
CREATE TABLE public.function_emails (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  function_name TEXT NOT NULL,
  department TEXT,
  local_part TEXT NOT NULL,
  domain TEXT NOT NULL DEFAULT 'asnk.org',
  forward_to TEXT NOT NULL,
  holder_name TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  notes TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (local_part, domain)
);

GRANT SELECT ON public.function_emails TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.function_emails TO authenticated;
GRANT ALL ON public.function_emails TO service_role;

ALTER TABLE public.function_emails ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view active emails" ON public.function_emails
  FOR SELECT USING (active = true);

CREATE POLICY "Admins manage all emails" ON public.function_emails
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

CREATE TRIGGER trg_function_emails_updated
  BEFORE UPDATE ON public.function_emails
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();
